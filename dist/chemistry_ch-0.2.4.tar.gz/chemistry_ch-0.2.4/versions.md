## Versions

0.0.1 - initial build
0.0.2 - renamed files + cleanup
0.0.3 - debugging package issue
0.0.4 - debugging package issue
0.0.5 - debugging package issue
0.0.6 - debugging package issue
0.0.7 - debugging package issue
0.0.8 - debugging package issue
0.0.9 - fixed package issue
0.1.0 - started conversions
0.1.1 - circular import issue
0.1.2 - circular import issue
0.1.3 - circular import issue
0.1.4 - fixed circular import issue
0.1.5 - added functions to periodic and conversions
0.1.6 - added MANIFEST to package other files too
0.1.7 - moved periodic.json to root
0.1.8 - added __init__ to src
0.1.9 - moved periodic.py to chemistry
0.1.10 - moved periodic.json to chemistry
0.1.11 - tested new file opener for JSON
0.1.12 - implemented file opener for JSON
0.2.0 - basics of periodic.py done
0.2.1 - added descriptions to functions and added to formulas.py
0.2.2 - added to period.py and fixed output type
0.2.3 - edited README and added to periodic
0.2.4 - added periodic.molar_mass