def testing(a):
    return a